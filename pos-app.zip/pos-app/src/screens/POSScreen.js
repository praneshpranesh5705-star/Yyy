import React from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useApp } from '../context/AppContext';
import { colors, spacing, type, radius } from '../theme';

export default function POSScreen() {
  const { items, cart, cartTotal, addToCart, setCartQty, removeFromCart, completeSale } = useApp();

  const handleCompleteSale = () => {
    if (cart.length === 0) return;
    const sale = completeSale();
    if (sale) {
      Alert.alert('Sale complete', `₹${sale.total.toFixed(2)} — ${sale.items.length} item(s)`);
    }
  };

  return (
    <SafeAreaView style={styles.screen} edges={['top']}>
      <Text style={type.title}>Billing</Text>

      <Text style={[type.section, styles.sectionSpacing]}>Items</Text>
      <FlatList
        data={items}
        keyExtractor={(it) => it.id}
        horizontal={false}
        numColumns={2}
        columnWrapperStyle={{ gap: spacing.sm }}
        contentContainerStyle={{ gap: spacing.sm, paddingBottom: spacing.sm }}
        style={{ maxHeight: 240 }}
        renderItem={({ item }) => (
          <TouchableOpacity style={styles.itemCard} onPress={() => addToCart(item)}>
            <Text style={type.body} numberOfLines={1}>{item.name}</Text>
            <Text style={type.price}>₹{item.price}</Text>
            <Text style={type.bodyMuted}>Stock: {item.stock}</Text>
          </TouchableOpacity>
        )}
        ListEmptyComponent={
          <Text style={type.bodyMuted}>No items yet — add some in the Inventory tab.</Text>
        }
      />

      <Text style={[type.section, styles.sectionSpacing]}>Cart</Text>
      <FlatList
        data={cart}
        keyExtractor={(c) => c.id}
        style={{ flex: 1 }}
        contentContainerStyle={{ gap: spacing.xs }}
        renderItem={({ item }) => (
          <View style={styles.cartRow}>
            <View style={{ flex: 1 }}>
              <Text style={type.body}>{item.name}</Text>
              <Text style={type.bodyMuted}>₹{item.price} each</Text>
            </View>
            <View style={styles.qtyControls}>
              <TouchableOpacity style={styles.qtyBtn} onPress={() => setCartQty(item.id, item.qty - 1)}>
                <Text style={styles.qtyBtnText}>–</Text>
              </TouchableOpacity>
              <Text style={styles.qtyValue}>{item.qty}</Text>
              <TouchableOpacity style={styles.qtyBtn} onPress={() => setCartQty(item.id, item.qty + 1)}>
                <Text style={styles.qtyBtnText}>+</Text>
              </TouchableOpacity>
            </View>
            <Text style={[type.price, { width: 72, textAlign: 'right' }]}>
              ₹{(item.price * item.qty).toFixed(0)}
            </Text>
            <TouchableOpacity onPress={() => removeFromCart(item.id)} style={{ paddingLeft: spacing.sm }}>
              <Text style={{ color: colors.danger, fontSize: 18 }}>×</Text>
            </TouchableOpacity>
          </View>
        )}
        ListEmptyComponent={
          <Text style={type.bodyMuted}>Cart is empty — tap an item above to add it.</Text>
        }
      />

      <View style={styles.footer}>
        <View style={styles.totalRow}>
          <Text style={type.section}>Total</Text>
          <Text style={type.total}>₹{cartTotal.toFixed(2)}</Text>
        </View>
        <TouchableOpacity
          style={[styles.completeBtn, cart.length === 0 && styles.completeBtnDisabled]}
          onPress={handleCompleteSale}
          disabled={cart.length === 0}
        >
          <Text style={styles.completeBtnText}>Complete sale</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.bg, padding: spacing.md },
  sectionSpacing: { marginTop: spacing.md, marginBottom: spacing.xs },
  itemCard: {
    flex: 1,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    padding: spacing.sm,
    minHeight: 78,
    justifyContent: 'center',
  },
  cartRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.sm,
    padding: spacing.sm,
  },
  qtyControls: { flexDirection: 'row', alignItems: 'center', gap: spacing.xs, marginHorizontal: spacing.sm },
  qtyBtn: {
    width: 28,
    height: 28,
    borderRadius: radius.sm,
    backgroundColor: colors.accentSoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  qtyBtnText: { color: colors.accent, fontSize: 18, fontWeight: '700' },
  qtyValue: { minWidth: 20, textAlign: 'center', fontWeight: '600' },
  footer: { borderTopWidth: 1, borderTopColor: colors.border, paddingTop: spacing.sm, marginTop: spacing.sm },
  totalRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: spacing.sm },
  completeBtn: {
    backgroundColor: colors.accent,
    borderRadius: radius.md,
    paddingVertical: spacing.sm + 4,
    alignItems: 'center',
  },
  completeBtnDisabled: { opacity: 0.4 },
  completeBtnText: { color: '#FFFFFF', fontSize: 16, fontWeight: '700' },
});
