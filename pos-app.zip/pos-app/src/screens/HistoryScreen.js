import React, { useMemo, useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useApp } from '../context/AppContext';
import { colors, spacing, type, radius } from '../theme';

function formatDate(iso) {
  const d = new Date(iso);
  return d.toLocaleDateString(undefined, { day: '2-digit', month: 'short' }) +
    ' · ' + d.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
}

export default function HistoryScreen() {
  const { sales } = useApp();
  const [expandedId, setExpandedId] = useState(null);

  const todayTotal = useMemo(() => {
    const today = new Date().toDateString();
    return sales
      .filter((s) => new Date(s.date).toDateString() === today)
      .reduce((sum, s) => sum + s.total, 0);
  }, [sales]);

  return (
    <SafeAreaView style={styles.screen} edges={['top']}>
      <Text style={type.title}>History</Text>

      <View style={styles.summaryCard}>
        <Text style={type.section}>Today's sales</Text>
        <Text style={type.total}>₹{todayTotal.toFixed(2)}</Text>
      </View>

      <FlatList
        data={sales}
        keyExtractor={(s) => s.id}
        contentContainerStyle={{ gap: spacing.sm, paddingTop: spacing.md }}
        renderItem={({ item }) => {
          const expanded = expandedId === item.id;
          return (
            <TouchableOpacity
              style={styles.saleCard}
              onPress={() => setExpandedId(expanded ? null : item.id)}
            >
              <View style={styles.saleHeader}>
                <Text style={type.bodyMuted}>{formatDate(item.date)}</Text>
                <Text style={type.price}>₹{item.total.toFixed(2)}</Text>
              </View>
              <Text style={type.bodyMuted}>{item.items.length} item(s) {expanded ? '▲' : '▼'}</Text>
              {expanded && (
                <View style={styles.itemsList}>
                  {item.items.map((it) => (
                    <View key={it.id} style={styles.itemLine}>
                      <Text style={type.body}>{it.name} × {it.qty}</Text>
                      <Text style={type.bodyMuted}>₹{(it.price * it.qty).toFixed(0)}</Text>
                    </View>
                  ))}
                </View>
              )}
            </TouchableOpacity>
          );
        }}
        ListEmptyComponent={<Text style={type.bodyMuted}>No sales recorded yet.</Text>}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.bg, padding: spacing.md },
  summaryCard: {
    backgroundColor: colors.accentSoft,
    borderRadius: radius.md,
    padding: spacing.md,
    marginTop: spacing.md,
  },
  saleCard: {
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.sm,
    padding: spacing.sm,
  },
  saleHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 },
  itemsList: { marginTop: spacing.sm, borderTopWidth: 1, borderTopColor: colors.border, paddingTop: spacing.sm, gap: 4 },
  itemLine: { flexDirection: 'row', justifyContent: 'space-between' },
});
