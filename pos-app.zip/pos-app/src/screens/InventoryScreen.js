import React, { useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, TextInput, StyleSheet, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useApp } from '../context/AppContext';
import { colors, spacing, type, radius } from '../theme';

export default function InventoryScreen() {
  const { items, addItem, updateItem, deleteItem } = useApp();
  const [editingId, setEditingId] = useState(null);
  const [draft, setDraft] = useState({ name: '', price: '', stock: '' });
  const [showAdd, setShowAdd] = useState(false);

  const startEdit = (item) => {
    setEditingId(item.id);
    setDraft({ name: item.name, price: String(item.price), stock: String(item.stock) });
  };

  const saveEdit = () => {
    if (!draft.name.trim()) return;
    updateItem(editingId, {
      name: draft.name.trim(),
      price: Number(draft.price) || 0,
      stock: Number(draft.stock) || 0,
    });
    setEditingId(null);
  };

  const saveNew = () => {
    if (!draft.name.trim()) return;
    addItem({
      name: draft.name.trim(),
      price: Number(draft.price) || 0,
      stock: Number(draft.stock) || 0,
    });
    setDraft({ name: '', price: '', stock: '' });
    setShowAdd(false);
  };

  const confirmDelete = (item) => {
    Alert.alert('Remove item', `Remove "${item.name}" from inventory?`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Remove', style: 'destructive', onPress: () => deleteItem(item.id) },
    ]);
  };

  return (
    <SafeAreaView style={styles.screen} edges={['top']}>
      <View style={styles.headerRow}>
        <Text style={type.title}>Inventory</Text>
        <TouchableOpacity
          style={styles.addBtn}
          onPress={() => {
            setEditingId(null);
            setDraft({ name: '', price: '', stock: '' });
            setShowAdd((s) => !s);
          }}
        >
          <Text style={styles.addBtnText}>{showAdd ? 'Cancel' : '+ Add item'}</Text>
        </TouchableOpacity>
      </View>

      {showAdd && (
        <View style={styles.form}>
          <TextInput
            style={styles.input}
            placeholder="Item name"
            value={draft.name}
            onChangeText={(v) => setDraft((d) => ({ ...d, name: v }))}
          />
          <View style={styles.formRow}>
            <TextInput
              style={[styles.input, { flex: 1 }]}
              placeholder="Price (₹)"
              keyboardType="numeric"
              value={draft.price}
              onChangeText={(v) => setDraft((d) => ({ ...d, price: v }))}
            />
            <TextInput
              style={[styles.input, { flex: 1 }]}
              placeholder="Stock qty"
              keyboardType="numeric"
              value={draft.stock}
              onChangeText={(v) => setDraft((d) => ({ ...d, stock: v }))}
            />
          </View>
          <TouchableOpacity style={styles.saveBtn} onPress={saveNew}>
            <Text style={styles.saveBtnText}>Save item</Text>
          </TouchableOpacity>
        </View>
      )}

      <FlatList
        data={items}
        keyExtractor={(it) => it.id}
        contentContainerStyle={{ gap: spacing.sm, paddingTop: spacing.sm }}
        renderItem={({ item }) =>
          editingId === item.id ? (
            <View style={styles.form}>
              <TextInput
                style={styles.input}
                value={draft.name}
                onChangeText={(v) => setDraft((d) => ({ ...d, name: v }))}
              />
              <View style={styles.formRow}>
                <TextInput
                  style={[styles.input, { flex: 1 }]}
                  keyboardType="numeric"
                  value={draft.price}
                  onChangeText={(v) => setDraft((d) => ({ ...d, price: v }))}
                />
                <TextInput
                  style={[styles.input, { flex: 1 }]}
                  keyboardType="numeric"
                  value={draft.stock}
                  onChangeText={(v) => setDraft((d) => ({ ...d, stock: v }))}
                />
              </View>
              <View style={styles.formRow}>
                <TouchableOpacity style={[styles.saveBtn, { flex: 1 }]} onPress={saveEdit}>
                  <Text style={styles.saveBtnText}>Save</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.saveBtn, { flex: 1, backgroundColor: colors.inkMuted }]}
                  onPress={() => setEditingId(null)}
                >
                  <Text style={styles.saveBtnText}>Cancel</Text>
                </TouchableOpacity>
              </View>
            </View>
          ) : (
            <View style={styles.row}>
              <View style={{ flex: 1 }}>
                <Text style={type.body}>{item.name}</Text>
                <Text style={type.bodyMuted}>₹{item.price} · Stock: {item.stock}</Text>
              </View>
              <TouchableOpacity onPress={() => startEdit(item)} style={styles.iconBtn}>
                <Text style={{ color: colors.accent, fontWeight: '600' }}>Edit</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => confirmDelete(item)} style={styles.iconBtn}>
                <Text style={{ color: colors.danger, fontWeight: '600' }}>Delete</Text>
              </TouchableOpacity>
            </View>
          )
        }
        ListEmptyComponent={<Text style={type.bodyMuted}>No items yet. Add your first one above.</Text>}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.bg, padding: spacing.md },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  addBtn: { backgroundColor: colors.accentSoft, borderRadius: radius.sm, paddingVertical: 6, paddingHorizontal: 12 },
  addBtnText: { color: colors.accent, fontWeight: '700' },
  form: {
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    padding: spacing.sm,
    gap: spacing.sm,
    marginTop: spacing.sm,
  },
  formRow: { flexDirection: 'row', gap: spacing.sm },
  input: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.sm,
    paddingHorizontal: spacing.sm,
    paddingVertical: 8,
    fontSize: 16,
    backgroundColor: '#FFFFFF',
  },
  saveBtn: { backgroundColor: colors.accent, borderRadius: radius.sm, paddingVertical: 10, alignItems: 'center' },
  saveBtnText: { color: '#FFFFFF', fontWeight: '700' },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.sm,
    padding: spacing.sm,
  },
  iconBtn: { paddingHorizontal: spacing.sm },
});
