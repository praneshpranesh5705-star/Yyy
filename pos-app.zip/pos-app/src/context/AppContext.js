import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const ITEMS_KEY = 'pos_items_v1';
const SALES_KEY = 'pos_sales_v1';

const AppContext = createContext(null);

const SAMPLE_ITEMS = [
  { id: 's1', name: 'Cotton Saree', price: 850, stock: 12 },
  { id: 's2', name: 'Kids T-Shirt', price: 220, stock: 40 },
  { id: 's3', name: 'Bedsheet Set', price: 650, stock: 8 },
];

export function AppProvider({ children }) {
  const [items, setItems] = useState([]);
  const [cart, setCart] = useState([]);
  const [sales, setSales] = useState([]);
  const [loaded, setLoaded] = useState(false);

  // Load persisted data once on startup.
  useEffect(() => {
    (async () => {
      try {
        const [rawItems, rawSales] = await Promise.all([
          AsyncStorage.getItem(ITEMS_KEY),
          AsyncStorage.getItem(SALES_KEY),
        ]);
        setItems(rawItems ? JSON.parse(rawItems) : SAMPLE_ITEMS);
        setSales(rawSales ? JSON.parse(rawSales) : []);
      } catch (e) {
        setItems(SAMPLE_ITEMS);
        setSales([]);
      } finally {
        setLoaded(true);
      }
    })();
  }, []);

  // Persist whenever items or sales change (after initial load).
  useEffect(() => {
    if (loaded) AsyncStorage.setItem(ITEMS_KEY, JSON.stringify(items)).catch(() => {});
  }, [items, loaded]);

  useEffect(() => {
    if (loaded) AsyncStorage.setItem(SALES_KEY, JSON.stringify(sales)).catch(() => {});
  }, [sales, loaded]);

  const addItem = useCallback((item) => {
    setItems((prev) => [...prev, { ...item, id: String(Date.now()) }]);
  }, []);

  const updateItem = useCallback((id, patch) => {
    setItems((prev) => prev.map((it) => (it.id === id ? { ...it, ...patch } : it)));
  }, []);

  const deleteItem = useCallback((id) => {
    setItems((prev) => prev.filter((it) => it.id !== id));
  }, []);

  const addToCart = useCallback((item) => {
    setCart((prev) => {
      const existing = prev.find((c) => c.id === item.id);
      if (existing) {
        return prev.map((c) => (c.id === item.id ? { ...c, qty: c.qty + 1 } : c));
      }
      return [...prev, { id: item.id, name: item.name, price: item.price, qty: 1 }];
    });
  }, []);

  const setCartQty = useCallback((id, qty) => {
    setCart((prev) => {
      if (qty <= 0) return prev.filter((c) => c.id !== id);
      return prev.map((c) => (c.id === id ? { ...c, qty } : c));
    });
  }, []);

  const removeFromCart = useCallback((id) => {
    setCart((prev) => prev.filter((c) => c.id !== id));
  }, []);

  const clearCart = useCallback(() => setCart([]), []);

  const cartTotal = cart.reduce((sum, c) => sum + c.price * c.qty, 0);

  const completeSale = useCallback(() => {
    if (cart.length === 0) return null;
    const sale = {
      id: String(Date.now()),
      date: new Date().toISOString(),
      items: cart,
      total: cart.reduce((sum, c) => sum + c.price * c.qty, 0),
    };
    setSales((prev) => [sale, ...prev]);
    // Reduce stock for items that track it.
    setItems((prev) =>
      prev.map((it) => {
        const sold = cart.find((c) => c.id === it.id);
        if (!sold) return it;
        return { ...it, stock: Math.max(0, (it.stock || 0) - sold.qty) };
      })
    );
    setCart([]);
    return sale;
  }, [cart]);

  return (
    <AppContext.Provider
      value={{
        items,
        cart,
        sales,
        cartTotal,
        addItem,
        updateItem,
        deleteItem,
        addToCart,
        setCartQty,
        removeFromCart,
        clearCart,
        completeSale,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used inside AppProvider');
  return ctx;
}
