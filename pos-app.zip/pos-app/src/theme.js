// A quiet, functional palette for a tool used dozens of times a day at a counter.
// Deep teal reads as "trustworthy ledger" without leaning on generic SaaS blue.
export const colors = {
  bg: '#F6F4EF',
  surface: '#FFFFFF',
  border: '#E4E0D6',
  ink: '#1F2420',
  inkMuted: '#6B7268',
  accent: '#0F5C56',
  accentSoft: '#E4F0EE',
  danger: '#B3452C',
  warn: '#B08900',
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
};

export const type = {
  title: { fontSize: 22, fontWeight: '700', color: colors.ink },
  section: { fontSize: 15, fontWeight: '600', color: colors.inkMuted },
  body: { fontSize: 16, color: colors.ink },
  bodyMuted: { fontSize: 14, color: colors.inkMuted },
  price: { fontSize: 16, fontWeight: '700', color: colors.ink },
  total: { fontSize: 24, fontWeight: '800', color: colors.accent },
};

export const radius = { sm: 8, md: 12, lg: 18 };
